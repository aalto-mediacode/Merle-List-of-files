#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    ofBackground(0);
    ofSetFrameRate(60);
    string myType[]{"png","jpg","tiff","mov","mp4","pdf","ttf","imovieevent","psd","aep","svg","ai","zip"};
    for(int i=0;i<numRows;i++){
        fileType[i]=myType[i];
        myRows[i].setup();
    }
}

//--------------------------------------------------------------
void ofApp::update(){
    for(int i=0;i<numRows;i++){
        myRows[i].update();
    }

}

//--------------------------------------------------------------
void ofApp::draw(){
    float myHeight=ofGetHeight()/numRows;
    for(int i=0; i<numRows; i++){
      
        ofColor newColor;
        newColor = 0;
        myRows[i].draw(i*myHeight, myHeight, newColor, fileType[i], i);
        
        
    }
}

//--------------------------------------------------------------
void ofApp::exit(){

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseScrolled(int x, int y, float scrollX, float scrollY){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
