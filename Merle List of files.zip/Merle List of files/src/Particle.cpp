
#include "Particle.hpp"

//--------------------------------------------------------------
void Particle::setup(){
 
    numLines[0] = 612;
    numLines[1] = 361;
    numLines[2] = 283;
    numLines[3] = 142;
    numLines[4] = 100;
    numLines[5] = 36;
    numLines[6] = 21;
    numLines[7] = 15;
    numLines[8] = 11;
    numLines[9] = 9;
    numLines[10] = 8;
    numLines[11] = 7;
    numLines[12] = 4;
    
    counter =0;
    loopLength=ofRandom(10,60);
    xSpeed=ofRandom(-5,5);
    newX=0;
}

//--------------------------------------------------------------
void Particle::update(){
    
 
    if(counter<60){
        counter++;
    }else{
        counter=0;
    }
     
    newX+=xSpeed;
    float max=600;
    if(newX>max || newX<-max){
        xSpeed*=-1;
    }
}

//--------------------------------------------------------------
void Particle::draw(float y, float h, ofColor myColor, string myString, int rowIndex){
    
    //rows with lines
    int lineCount = numLines[rowIndex];
    ofSetColor(myColor);
    ofDrawRectangle(0,y,ofGetWidth(),h);
    ofSetLineWidth(1.5);
       for (int i = 0; i < lineCount; i++) {
           float myX = ofMap(i, 0, lineCount, 0, ofGetWidth());
           drawLine(myX, y, h);
       }
   
    //legend
    ofSetColor(255);
    ofDrawCircle(20, y+h/2, 5);
    ofDrawBitmapString(myString, 45, y+h/2+4); //+4 to lower the baseline and center the text
}
void Particle::drawLine(float x, float y, float h){
  
    x+=newX;
  
    ofSetColor(255,0,0,250);
    ofDrawLine(x+counter/3, y, x+counter/3, y+h);
    ofSetColor(0,255,0,250);
    ofDrawLine(x+counter/1.5, y, x+counter/1.5, y+h);
    ofSetColor(0,0,255,250);
    ofDrawLine(x+counter/1.1, y, x+counter/1.1, y+h);
    //white lines
    ofSetColor(255);
    ofDrawLine(x, y, x, y+h);
}

