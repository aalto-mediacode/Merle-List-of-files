#pragma once

#include "ofMain.h"

class Particle{
    
public:
    void setup() ;
    void update() ;
    void draw(float y, float h, ofColor myColor, string myString, int rowIndex) ;
    void drawLine(float x, float y, float h);

    
    string fileType;
    int lines;
    int numLines[13];
    float counter;
    float loopLength;
    float xSpeed;
    float newX;
};
